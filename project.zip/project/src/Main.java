import ru.ifmo.se.pokemon.Battle;
import pokemons.*;

public class Main {
    public static void main(String[] args) {
        // Создаем симулятор боя
        Battle b = new Battle();

        // 1. Создаем ваших покемонов с оригинальными именами и уровнями
        // Уровни выставлены минимальные для доступа ко всем атакам
        Shinx shinx = new Shinx("Shinx", 1);
        Drifloon drifloon = new Drifloon("Drifloon", 1);
        Masquerain masquerain = new Masquerain("Masquerain", 1);
        Pansear pansear = new Pansear("Pansear", 1);
        Luvdisc luvdisc = new Luvdisc("Luvdisc", 1);
        Simisear simisear = new Simisear("Simisear", 1);

        // 2. Распределяем их по командам (например, 3 на 3)
        b.addAlly(shinx);
        b.addAlly(masquerain);
        b.addAlly(pansear);

        b.addFoe(drifloon);
        b.addFoe(luvdisc);
        b.addFoe(simisear);

        // 3. Запускаем бой
        b.go();
    }
}
