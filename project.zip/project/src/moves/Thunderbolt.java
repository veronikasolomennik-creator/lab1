package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class Thunderbolt extends Move {
    public Thunderbolt() {
        super(Type.ELECTRIC, 90, 100);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
    }

    @Override
    protected String describe() {
        return "использует Thunderbolt";
    }
}
