package moves;

import ru.ifmo.se.pokemon.SpecialMove;
import ru.ifmo.se.pokemon.Type;

public final class MegaDrain extends SpecialMove {
    public MegaDrain() {
        super(Type.GRASS, 40, 100);
    }
    @Override
    protected String describe() {
        return "высасывает энергию соперника атакой Mega Drain";
    }
}
