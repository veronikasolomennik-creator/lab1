package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class NightShade extends Move {
    public NightShade() {
        super(Type.GHOST, 0, 100);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
    }

    @Override
    protected String describe() {
        return "использует Night Shade";
    }
}
