package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class Bite extends Move {
    public Bite() {
        super(Type.DARK, 60, 100);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
        // Метод оставляем пустым, библиотека сама посчитает урон на основе power и accuracy
    }

    @Override
    protected String describe() {
        return "использует Bite";
    }
}
