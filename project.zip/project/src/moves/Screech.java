package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class Screech extends Move {
    public Screech() {
        super(Type.NORMAL, 0, 85);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
    }

    @Override
    protected String describe() {
        return "использует Screech";
    }
}
