package moves;

import ru.ifmo.se.pokemon.SpecialMove;
import ru.ifmo.se.pokemon.Type;

public final class StoredPower extends SpecialMove {
    public StoredPower() {
        super(Type.PSYCHIC, 20, 100);
    }
    @Override
    protected String describe() {
        return "высвобождает накопленную ментальную силу Stored Power";
    }
}
