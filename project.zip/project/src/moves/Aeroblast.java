package moves;

import ru.ifmo.se.pokemon.SpecialMove;
import ru.ifmo.se.pokemon.Type;

public final class Aeroblast extends SpecialMove {
    public Aeroblast() {
        super(Type.FLYING, 100, 95);
    }
    @Override
    protected String describe() {
        return "выпускает сокрушительный воздушный поток Aeroblast";
    }
}
