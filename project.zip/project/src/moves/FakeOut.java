package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class FakeOut extends Move {
    public FakeOut() {
        super(Type.NORMAL, 40, 100);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
    }

    @Override
    protected String describe() {
        return "использует Fake Out";
    }
}
