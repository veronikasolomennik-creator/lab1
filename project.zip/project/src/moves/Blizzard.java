package moves;

import ru.ifmo.se.pokemon.Move;
import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;

public final class Blizzard extends Move {
    public Blizzard() {
        super(Type.ICE, 110, 70);
    }

    @Override
    protected void attack(Pokemon att, Pokemon def) {
    }

    @Override
    protected String describe() {
        return "использует Blizzard";
    }
}
