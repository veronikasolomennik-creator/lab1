package pokemons;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;
import moves.*;

public class Pansear extends Pokemon {
    public Pansear(String name, int level) {
        super(name, level);
        setStats(50, 53, 48, 53, 48, 64);
        setType(Type.FIRE);

        // Атаки Pansear со скриншота:
        addMove(new FakeOut());
        addMove(new Psychic());
    }
}
