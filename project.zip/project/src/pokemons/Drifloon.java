package pokemons;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;
import moves.*;

public final class Drifloon extends Pokemon {
    public Drifloon(String name, int level) {
        super(name, level);
        setStats(90, 50, 34, 60, 44, 70);
        setType(Type.GHOST, Type.FLYING);

        // Атаки Drifloon со скриншота:
        addMove(new Blizzard());
        addMove(new StoredPower());
        addMove(new Thunderbolt());
    }
}
