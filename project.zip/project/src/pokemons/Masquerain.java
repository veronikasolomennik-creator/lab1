package pokemons;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;
import moves.*;

public final class Masquerain extends Pokemon {
    public Masquerain(String name, int level) {
        super(name, level);
        setStats(70, 60, 62, 100, 82, 80);
        setType(Type.BUG, Type.FLYING);

        // Атаки Masquerain со скриншота:
        addMove(new Blizzard());
        addMove(new StoredPower());
        addMove(new Thunderbolt());
        addMove(new FurySwipes());
    }
}
