package pokemons;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;
import moves.*;

public final class Shinx extends Pokemon {
    public Shinx(String name, int level) {
        super(name, level);
        setStats(45, 65, 34, 40, 34, 45);
        setType(Type.ELECTRIC);

        // Атаки Shinx со скриншота:
        addMove(new Assurance());
        addMove(new MegaDrain());
        addMove(new Aeroblast());
        addMove(new Bite());
    }
}
