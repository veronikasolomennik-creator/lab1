package pokemons;

import ru.ifmo.se.pokemon.Type;
import moves.*;

public final class Simisear extends Pansear {
    public Simisear(String name, int level) {
        super(name, level); // Наследует тип FIRE и базовые атаки от Pansear
        setStats(75, 98, 63, 98, 63, 101);

        // Дополнительные атаки Simisear со скриншота:
        addMove(new Screech());
        addMove(new NightShade());
    }
}
