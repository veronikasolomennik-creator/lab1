package pokemons;

import ru.ifmo.se.pokemon.Pokemon;
import ru.ifmo.se.pokemon.Type;
import moves.*;

public final class Luvdisc extends Pokemon {
    public Luvdisc(String name, int level) {
        super(name, level);
        setStats(43, 30, 55, 40, 65, 97);
        setType(Type.WATER);

        // Атаки Luvdisc со скриншота:
        addMove(new FakeOut());
        addMove(new Psychic());
        addMove(new Screech());
    }
}
